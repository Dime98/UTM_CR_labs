#!/bin/bash

if [ "$#" == "0" ]; then 
    echo "introduceti site ca argument!" 
    exit 1
fi 

DOMAINS=( '.com' '.co.uk' '.net' '.info' '.mobi' '.org' '.tel' '.biz' '.tv' '.cc' '.eu' '.ru' '.in' '.it' '.sk' '.com.au' )
 
ELEMENTS=${#DOMAINS[@]} 


echo "for $1" >> file
 

for (( i=0;i<$ELEMENTS;i++)); do 

	if curl -s http://www.$1${DOMAINS[${i}]} >/dev/null
	then
	  echo "[+] http://www.$1${DOMAINS[${i}]} online"
	  echo "$1${DOMAINS[${i}]} OK" >> file
	else
	  echo "[-] http://www.$1${DOMAINS[${i}]} offline"
	fi

done 
 


