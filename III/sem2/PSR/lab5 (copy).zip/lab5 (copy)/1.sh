#!/bin/bash

sudo ifconfig > test.txt
sudo ifconfig > test3.txt
echo $ifconfig
grep -i "inet " test.txt > test1.txt
head -1 test1.txt > test.txt
data1=$( cut -b 13-23 test.txt )
data2=$( cut -b 33-47 test.txt )
echo addr $data1 
echo mask $data2

rm test.txt

if_ping() {
	sudo ping -c 1 $1 > /dev/null
	if [ $? -eq 0 ]
	then
		echo dev $i e activ >> test.txt
	fi
}

for i in "$data1"{1..254}
do
	if_ping $i & disown
done

cat test.txt 2> /dev/null

if [ $? -eq 0 ]
	then
		echo
	else
		echo "nu aaveti acces la retea"
	fi	

rm test.txt 2> /dev/null

