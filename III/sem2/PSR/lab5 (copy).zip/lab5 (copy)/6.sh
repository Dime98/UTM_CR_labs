#!/bin/bash
x=1
s=0
z=0
while [ $x -ne 12 ]
do
	z=$(($x%2))
	if [ $z -eq 0 ] 
	then
		echo $x
		let s=s+x
	fi
	x=$(( $x + 1 ))
done

echo "suma $s"

exit 0