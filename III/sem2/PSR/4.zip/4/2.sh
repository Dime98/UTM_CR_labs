#!/bin/bash

clear
if [ $# -eq 0 ] 
then	
	ls ../home/user
else
	ls ../$1
fi


