#!/bin/bash

if [ -d "$1" ] 
then
	find $1 | wc -l
else
	echo "dir nu exista"
fi


exit 0