#!/bin/bash

# clear
# ls -l

# Get no of args
noArgs=$#
# Save arguments in array
myArr=("$@")

# Loop the array
for ((i=0; i<$noArgs; i++)); do
    echo $((i+1)). ${myArr[$i]}
done


if [ $# -eq 0 ]; then
	echo nici un arg
fi


exit 0