#!/bin/bash
 
# Declare an array of string with type
declare -a StringArray=("January" "February" "March" "April" "May" "June" "July" "August" "September" "October" "November" "December")
z=$(($1-1))

echo ${StringArray[$z]}
# Iterate the string array using for loop
# for val in ${StringArray[@]}; do
#    echo $val
# done

