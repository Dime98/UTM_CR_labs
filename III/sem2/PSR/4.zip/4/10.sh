#!/bin/bash
x=0
z=0
s=0
echo -e "until do done, media"


until [ $x -eq $1 ]
do
	x=$(( $x + 1 ))
	echo $x
	let s=s+x
done

# let s=s/$1
echo suma $s
s=$(( $s / $1 ))
echo media $s

exit 0