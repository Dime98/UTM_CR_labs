#!/bin/bash

echo PID: $$

exit 0