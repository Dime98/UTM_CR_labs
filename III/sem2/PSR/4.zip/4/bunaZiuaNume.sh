#!/bin/bash
user=$(whoami)


if [ $# -eq 0 ] 
then
	echo "buna ziua " $user
else
	echo "buna ziua $1 $2"
fi


exit 0