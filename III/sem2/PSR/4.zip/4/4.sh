#!/bin/bash

if [ -d "$1" ] 
then
	cp -R $1 .
else
	echo "dir nu exista"
fi


exit 0