#include <stdio.h>
#include <sys/socket.h>
#include <unistd.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <string.h>

#define PORT 4000

/* Citeste cererea clientului. Pune numele fisierului intr-un string.
* Daca sintaxa nu este corecta sau lipsesk retururi la linii
* se trimite -1. In caz contrar functia transmite 0.
* requestFromClient este sirul de 1000 octeti care contine cererea provenita de la client.
* requestSize trebuie sa egala cu 1000 (si nu la lungimea sirului de caractere). 
*/

int parseRequest(char* requestFromClient, int requestSize, char* string, int stringSize)
{
    /* charPtr[4] este un tabel cu 4 pointere care poiteaza asupra inceputului sirului, cele 2 spatii   */
    /* ale cererii (cel de dupa GET si cel de dupa numelefisierului)    */
    /* Pointerul end se va utiliza pentru a pune un '\0' la sfarsitul returului dublu la linie.     */

    char *charPtr[4], *end;

    /* Se cauta dublul retur la linie in requestFromClient
    * in functie de sisteme de va utiliza \r sau \n (new line, new feed)
    * prin conventie in http se utilizeaza ambele \r\n dar in practic e vorba de un singur retur la linie.
    * Pentru a simplifica, aici se cauta doar '\n'.
    * Se va plasa un '\0' imediat dupa dublul retur la linie permitand prelucrarea cererii 
    * casi uilizarea functiilor din biblioteca string.h. 
    */

    /* Citire pana la dublul retur de linie */
    requestFromClient[requestSize-1]='\0';//Permite utilizarea strchr() - atentie, nu merge daca requestSize indica lungimea sirului de caractere

    if( (end=strstr(requestFromClient,"\r\n\r\n"))==NULL) return(9);
    *(end+4)='\0';
    
    // Verificarea syntaxei (GET fisier HTTP/1.1)       
    charPtr[0]=requestFromClient;   //Inceputul cererii (GET in principiu)
    //Se cauta primul spatiu, codul ascii 0x20 (in hexa), este inceputul numelui fisierului
    charPtr[1]=strchr(requestFromClient,' ');   
    if(charPtr[1]==NULL) return(1);
    charPtr[2]=strchr(charPtr[1]+1,' ');    
    if(charPtr[2]==NULL) return(2);
    charPtr[3]=strchr(charPtr[2]+1,'\r');   
    if(charPtr[3]==NULL) return(3);

    //Se separa sirurile
    *charPtr[1]='\0';
    *charPtr[2]='\0';
    *charPtr[3]='\0';

    if(strcmp(charPtr[0],"GET")!=0) return(4);
    if(strcmp(charPtr[2]+1,"HTTP/1.1")!=0) return(5);
    strncpy(string,charPtr[1]+2,stringSize);//Se decaleasa sirul cu 2 octeti: primul octet este '\0', al doilea decalaj permite sa retragem "/" 

    //Daca stringSize nu este suficient de mare, sirul nu contine '\0'. Pentru a verifica et suficient sa testam string[stringSize-1] care
    // trebuie sa fie = '\0' deoarece  strncpy unple sirul cu '\0' cand exista loc.
    if(string[stringSize-1]!='\0'){
        fprintf(stderr,"Erreur parseRequest(): lungimea sirului string nu este suficienta (stringSize=%d)\n",stringSize);
        exit(3);
    }
    
    //DEBUG 
    if( *(charPtr[1]+2) == '\0') fprintf(stderr,"DEBUG-SERVEUR: nomele fisieruui est vid -\nDEBUG-SERVEUR: - se asociaza fisierul implicit index.html\n");
    else fprintf(stderr,"DEBUG-SERVEUR: numele fisierului cerut este %s\n",string);

    if( *(charPtr[1]+2) == '\0') strcpy(string,"index.html");

    return(0);
}




int main(int argc, char const *argv[])
{
    int server_fd, new_socket; long valread;
    struct sockaddr_in address;
    int addrlen = sizeof(address);
    
    // Only this line has been changed. Everything is same.
    char *msg = "HTTP/1.1 400 BAD REQUEST\nContent-Type: text/plain";
    char *msg2 = "HTTP/1.1 404 FILE NOT FOUND\nContent-Type: text/plain";
    
    // Creating socket file descriptor
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0)
    {
        perror("In socket");
        exit(EXIT_FAILURE);
    }
    

    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons( PORT );
    
    memset(address.sin_zero, '\0', sizeof address.sin_zero);
    
    
    if (bind(server_fd, (struct sockaddr *)&address, sizeof(address))<0)
    {
        perror("In bind");
        exit(EXIT_FAILURE);
    }
    if (listen(server_fd, 10) < 0)
    {
        perror("In listen");
        exit(EXIT_FAILURE);
    }
   while(1)
    {
        printf("waitting\n");
        if ((new_socket = accept(server_fd, (struct sockaddr *)&address, (socklen_t*)&addrlen))<0)
        {
            perror("In accept");
            exit(EXIT_FAILURE);
        }
 
        char buffer[30000] = {0};
         char buffer1[1000];
         char buffer2[1000];
         FILE *source;
        valread = read( new_socket , buffer, 30000);
        printf("%s\n",buffer );
        int stat = parseRequest(buffer, 30000, buffer1, 1000);
        
    
        
        if (stat ==0)
        {

      
        source = fopen(buffer1, "r");
        if( source == NULL ){
          write(new_socket , msg2, strlen(msg2));
          printf("no such file\n");
          exit(EXIT_FAILURE);

        }
       else{
        while (fgets(buffer2,1000,source) != EOF)
        {
         puts(buffer2);
         write(new_socket , buffer2, strlen(buffer2));
        }
        
       
       }
       
         fclose(source);


        }

        else
        {
          write(new_socket , msg, strlen(msg));
        }
        
        
    }
    close(new_socket);
    return 0;
}



