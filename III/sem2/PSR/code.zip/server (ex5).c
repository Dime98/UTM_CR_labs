#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <sys/param.h>
#include <errno.h>

#define ERROR(s) {fprintf(stderr,"%d-",errno); perror(s); return(-1);}

int main (argc, argv)
int argc;
char *argv[];
{
    struct sockaddr_in sa;  
    struct sockaddr_in caller; 
    int ssd;
    int csd;
    int length;
    int retval;
    int action;
    char buf[BUFSIZ];
    char* prompt[]={">>",     
    "Available commands: \n\tput - to send a text to server \thelp - to view this help\n\tquit - to close the connection\n>>", "Enter the text terminating it with '.' in a new line.\n>>", "Enter a command\n>>"};

    if (argc != 2) {
        fprintf (stdout, "usage: %s hostname\n", argv[0]);
        exit (-1);
    }

    sa.sin_family= AF_INET;                         
    sa.sin_addr.s_addr = INADDR_ANY;                
    sa.sin_port= htons((u_short) atoi(argv[1]));    

    
    while (1) {
        int action = 0;
        printf ("Starting new connection:");
        sleep(5);

        
        if ((ssd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0)   
        ERROR ("socket");

        
        if (bind(ssd, (struct sockaddr *)&sa, sizeof sa) < 0) 
            ERROR ("bind");

        length = sizeof(sa);

        
        listen (ssd, 5);   

        
        if ((csd = accept(ssd, (struct sockaddr *)&caller, &length)) < 0)  
            ERROR ("accept");

        write(csd, prompt[0], strlen(prompt[0]));
        
        
        a:
        
        while(action != 2) { 
            if((retval = read(csd, buf, sizeof(buf))) < 0)
                ERROR("Reading stream message\n");
                buf[retval]='\0';

                if (strcmp(buf,"help\n") == 0) 
                    action = 0;
                if (strcmp(buf,"put\n") == 0) 
                    action = 1;
                if (strcmp(buf,"quit\n") == 0 || retval == 0) 
                    action = 2;
                if (strcmp(buf,".\n") == 0) 
                    action = 3;
                
                
                switch (action) { 
                    case 0:
                        write(csd, prompt[1], strlen(prompt[1]));
                        action =- 1;
                        break;
                    case 1:
                        write(csd, prompt[2], strlen(prompt[2]));
                        action = 4;
                        break;
                    case 2:
                        printf("\nEnding connection ...\n");
                        goto a;
                        break;
                    case 3:
                        write(csd, prompt[3], strlen(prompt[3]));
                        action =- 1;
                        break;
                    case 4 :
                        printf("%s", buf);
                        break;
                    default:
                        write(csd, prompt[3], strlen(prompt[3]));
                }
        }
        close(csd);
        close(ssd); 
    }
    exit(0);
}