#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <sys/param.h>
#include <errno.h>

// defenim eroare + ichidem programul
#define ERROR(s) {printf("%d-",errno); perror(s); return (-1);} 

char buf[BUFSIZ];

int main (argc, argv)
int argc;
char *argv[];
{
    int sock;
    struct sockaddr_in sa;
    struct hostent * host;
    int n;

    if (argc!=3) { 
        printf("Usage: %s hostname port\n",argv[0]);
        exit (-1);
    }

    // verificarea daca exita un soket pentru comunicare
    if((sock=socket(AF_INET, SOCK_STREAM, IPPROTO_TCP))<0)          
        ERROR("socket");

    // verificarea  host-ul 
    if((host=gethostbyname(argv[1]))==(struct hostent*)NULL) 
        ERROR("gethostbyname");

    // socket-ul preia adresa host-ului
    memcpy((char*)&sa.sin_addr, (char*)host->h_addr, host->h_length); 
    sa.sin_family=AF_INET;
    sa.sin_port=htons((u_short)atoi(argv[2]));

    // conetarea server-client
    if(connect(sock, (struct sockaddr *)&sa, sizeof sa) < 0) 
        ERROR("connect");

    while(strcmp(buf,"quit\n")!=0) { 
        while(!((buf[strlen(buf)-2]=='>') && (buf[strlen(buf)-1]=='>'))) {
            if ((n=read(sock, buf, sizeof(buf))) < 0) 
                ERROR("read");
            buf[n]=0;
            printf("%s", buf);
        } 
        if(strcmp(buf, "Enter the text terminating it with '.' in a new line.\n>>")==0) 
            while(buf[0]!='.') { 
            fgets(buf, sizeof(buf), stdin);
            if (write(sock, buf, strlen(buf))<0) 
                ERROR("write");
        }
        else {
            fgets(buf, sizeof(buf), stdin);
            if (write(sock, buf, strlen(buf))<0)
                ERROR("write");    
        } 
    }
}