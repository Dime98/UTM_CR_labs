#ifndef _STM32F103_MAIN_H_
#define _STM32F103_MAIN_H_

#include "stm32f10x.h"

#define HSE_VALUE    ((uint32_t)8000000) /*!< Value of the External oscillator in Hz */

#define LEDS_PORT		GPIOB->ODR

#define LED_RED     0		// HeartBeat Led PORT_B.0
#define LED_GREEN   1		// Status Led PORT_B.1

#define BUTTON			2		// Button on PORT_B.2 

void Delay_200mS( uint32_t Val);
void Delay_uSec(uint32_t uSec);

/*
const uint8_t card_codes[MAX_CARDS*CODE_LENGHT]={

}
*/
#endif
