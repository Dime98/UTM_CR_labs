// STM32F10X_MD

#include <string.h>

#include "Main.h"

char str[100];
volatile uint32_t msTicks_200 = 0;

int16_t i;

////////////////////////////////////////////////////////////////////////
int main()
{
	RCC->APB2ENR 	|= RCC_APB2ENR_IOPBEN;   // Conectam ceasul la PortulB

//    if (x>10) && (temp<5)    //  && -Logic "AND" ;
																//  || - Logic "OR"
																//   ! - Logic negation
	
																//   & - bitwise AND
																//   | - bitwise OR
																//   ^  - bitwise XOR
																//   ~  - bitwise NOT
		
	// PinB0 - 
	GPIOB->CRL	&= ~GPIO_CRL_CNF0;	// 00 - GPIO output, Push-Pull 
	GPIOB->CRL 	|= GPIO_CRL_MODE0_1;	// MODE10 = Max Speed 2MHz	
	
	GPIOB->BSRR |= GPIO_BSRR_BR0;	//pinB0 -> Low
	
	//SetUp pinB1 for LED
	GPIOB->CRL	&= ~GPIO_CRL_CNF1;	// 00 - GPIO output, Push-Pull 
	GPIOB->CRL 	|=  GPIO_CRL_MODE1;	// MODE10 = Max Speed 50MHz	
	
		// SetUP SysTimer
	SysTick_Config(SystemCoreClock / 10);      // Configure SysTick to generate an interrupt (max 2^24 tiks)
	
	//	USART_Init();
	__enable_irq ();	//Enable Global interrupt
	
	Delay_200mS(1);
	GPIOB->BSRR |= GPIO_BSRR_BS0;	//pinB0 -> High
	Delay_200mS(1);



	
	while (1){
		GPIOB->ODR ^= (1<<LED_RED);          //x ^ 1  = !x   x ^ 0 = x
 		Delay_200mS(5);	
	} //do nothing		


}

// utils
//------------------------------------------------------
void Delay_uSec(uint32_t uSec)
{
	uint8_t i;
	while (uSec > 0){
		for (i=0; i<36; i++){
			__nop();		
		}		
		uSec--;
	}

}

//---------------------------------------------------------------
void Delay_200mS( uint32_t Val) 
{
	msTicks_200 = Val;
	while(msTicks_200 > 0){;}
}

//---------------------------------------------------------------
void SysTick_Handler(void)
{
	GPIOB->ODR ^= (1<<LED_GREEN);
/*
	if(GPIOB->IDR & GPIO_IDR_IDR1){
		GPIOB->BSRR |= GPIO_BSRR_BR1;
	}else{
		GPIOB->BSRR |= GPIO_BSRR_BS1;
	}
*/
	if (msTicks_200 > 0){
		msTicks_200--;			// decrement at each 200mS 
	}
	
}



